#include "../../config.h"
#include "parser.h"

#include <assert.h>
#include <inttypes.h>  // PRId64
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "ast.h"
#include "expr.h"
#include "fe_misc.h"
#include "initializer.h"
#include "lexer.h"
#include "table.h"
#include "type.h"
#include "util.h"
#include "var.h"

static Stmt *parse_stmt(void);

bool parsing_stmt;

Token *consume(enum TokenKind kind, const char *error) {
  Token *tok = match(kind);
  if (tok == NULL)
    parse_error(PE_NOFATAL, tok, error);
  return tok;
}

static void add_func_goto_label(const Token *token, Stmt *goto_, Stmt *label) {
  assert(curfunc != NULL);
  Table *table = curfunc->label_table;
  if (table == NULL)
    curfunc->label_table = table = alloc_table();
  GotoLabel *goto_label = table_get(table, token->ident);
  if (goto_label == NULL) {
    goto_label = calloc_or_die(sizeof(*goto_label));
    goto_label->label_stmt = NULL;
    goto_label->gotos = new_vector();
    table_put(table, token->ident, goto_label);
  } else {
    if (label != NULL && goto_label->label_stmt != NULL) {
      parse_error(PE_NOFATAL, token, "label `%.*s' already defined", NAMES(token->ident));
      return;
    }
  }
  if (label != NULL)
    goto_label->label_stmt = label;
  if (goto_ != NULL)
    vec_push(goto_label->gotos, goto_);
}

static inline void check_goto_labels(Function *func) {
  Table *label_table = func->label_table;
  if (label_table == NULL)
    return;

  // Check whether goto label exist and used.
  const Name *name;
  GotoLabel *goto_label;
  for (int it = 0; (it = table_iterate(label_table, it, &name, (void**)&goto_label)) != -1; ) {
    if (goto_label->label_stmt == NULL) {
      assert(goto_label->gotos->len > 0);
      Stmt *stmt = goto_label->gotos->data[0];
      parse_error(PE_NOFATAL, stmt->goto_.label, "`%.*s' not found", NAMES(name));
    } else if (goto_label->gotos->len == 0) {
      parse_error(PE_WARNING, goto_label->label_stmt->token, "`%.*s' not used", NAMES(name));
    }
  }
}

//

// <initializer-list> ::= <initializer>
//                      | <initializer-list> , <initializer>
static Initializer *parse_initializer_multi(void) {
  Initializer *init = NULL;
  const Token *tok;
  if (match(TK_DOT)) {  // .member=value
    Token *ident = consume(TK_IDENT, "ident expected for dotted initializer");
    Initializer *value = parse_initializer_multi();
    if (value == NULL) {
      consume(TK_ASSIGN, "`=' expected for dotted initializer");
      value = parse_initializer();
    }
    if (ident != NULL) {
      init = new_initializer(IK_DOT, ident);
      init->dot.name = ident->ident;
      init->dot.value = value;
    }
  } else if ((tok = match(TK_LBRACKET)) != NULL) {
    Expr *expr = parse_const_fixnum();
    size_t index = 0;
    if (expr->fixnum < 0)
      parse_error(PE_NOFATAL, expr->token, "non negative integer required");
    else
      index = expr->fixnum;
    consume(TK_RBRACKET, "`]' expected");
    Initializer *value = parse_initializer_multi();
    if (value == NULL) {
      match(TK_ASSIGN);  // both accepted: `[1] = 2`, and `[1] 2`
      value = parse_initializer();
    }
    init = new_initializer(IK_BRKT, tok);
    init->bracket.index = index;
    init->bracket.value = value;
  }
  return init;
}

// <initializer> ::= <assignment-expression>
//                 | { <initializer-list> }
//                 | { <initializer-list> , }
Initializer *parse_initializer(void) {
  Initializer *result;
  const Token *lblace_tok;
  if ((lblace_tok = match(TK_LBRACE)) != NULL) {
    Vector *multi = new_vector();
    if (!match(TK_RBRACE)) {
      for (;;) {
        Initializer *init = parse_initializer_multi();
        if (init == NULL)
          init = parse_initializer();
        assert(init != NULL);
        vec_push(multi, init);

        if (match(TK_COMMA)) {
          if (match(TK_RBRACE))
            break;
        } else {
          consume(TK_RBRACE, "`}' or `,' expected");
          break;
        }
      }
    }
    result = new_initializer(IK_MULTI, lblace_tok);
    result->multi = multi;
  } else {
    Expr *value = parse_assign();
    value = used_as_value(value);
    result = new_initializer(IK_SINGLE, value->token);
    result->single = value;
  }
  return result;
}

//

static void def_type(Type *type, Token *ident) {
  const Name *name = ident->ident;
  Scope *scope;
  Type *defined = find_typedef(curscope, name, &scope);
  if (defined != NULL && scope == curscope) {
    if (same_type(type, defined))
      return;
    parse_error(PE_NOFATAL, ident, "conflict typedef");
  } else if (scope_find(curscope, ident->ident, &scope) != NULL && scope == curscope) {
    parse_error(PE_NOFATAL, ident, "conflict typedef with variable");
    return;
  }

  if (defined == NULL || (type->kind == TY_STRUCT && type->struct_.info != NULL)) {
    if (type->kind == TY_ARRAY) {
      if (!ensure_type_info(type, ident, curscope, true))
        return;
    }
    add_typedef(curscope, name, type);
  }
}

Type *parse_var_def(Type *rawType, ParsedTypeInfo *tinfo) {
  if (rawType == NULL) {
    rawType = parse_raw_type(tinfo);
    if (rawType == NULL)
      return NULL;
  }

  if (rawType->kind == TY_AUTO)
    return parse_direct_declarator(rawType, tinfo);

  return parse_declarator(rawType, tinfo);
}

static Vector *parse_vardecl_cont(Type *type, ParsedTypeInfo *tinfo) {
  Vector *decls = NULL;
  bool first = true;
  do {
    if (!first) {
      type = parse_var_def(tinfo->rawType, tinfo);
      if (type == NULL || tinfo->ident == NULL) {
        parse_error(PE_NOFATAL, NULL, "ident expected");
        return decls;
      }
    }
    first = false;

    if (match(TK_LPAR)) {  // Function prototype.
      bool vaargs;
      Vector *param_vars = parse_funparams(&vaargs);
      Vector *param_types = extract_varinfo_types(param_vars);
      type = new_func_type(type, param_types, vaargs);
      type->func.param_vars = param_vars;
    } else {
      if (!(tinfo->storage & VS_TYPEDEF)) {
        if (!not_void(type, NULL))
          type = &tyInt;  // Deceive to continue compiling.
      }
    }

    assert(!is_global_scope(curscope));

    if (!(tinfo->storage & (VS_EXTERN | VS_TYPEDEF)))
      ensure_type_info(type, tinfo->ident, curscope, true);

#ifndef __NO_VLA
    if (type->kind == TY_ARRAY && type->pa.vla != NULL)
      type = array_to_ptr(type);
#endif

    if (tinfo->storage & VS_TYPEDEF) {
#ifndef __NO_VLA
      Expr *assign_sizevar = reserve_vla_type_size(type);
      if (assign_sizevar != NULL) {
        Expr *e = assign_sizevar;
        while (e->kind == EX_COMMA)
          e = e->bop.rhs;
        assert(e->kind == EX_ASSIGN);
        Expr *size_var = e->bop.lhs;
        assert(size_var->kind == EX_VAR);

        VarInfo *varinfo = scope_find(size_var->var.scope, size_var->var.name, NULL);
        assert(varinfo != NULL);
        VarDecl *decl = new_vardecl(varinfo);
        decl->init_stmt = new_stmt_expr(assign_sizevar);
        if (decls == NULL)
          decls = new_vector();
        vec_push(decls, decl);
      }
#endif
      def_type(type, tinfo->ident);
      continue;
    }

#ifndef __NO_VLA
    if (curfunc != NULL) {
      Expr *size = calc_vla_size(type);
      if (size != NULL) {
        // If the type has VLA, assign its size to the temporary variable
        // adding dummy declaration (decl.ident = NULL).
        Expr *var = size;
        for (; var->kind == EX_COMMA; var = var->bop.rhs)
          ;
        if (var->kind == EX_ASSIGN) {
          var = var->bop.lhs;
        }
        assert(var->kind == EX_VAR);
        VarInfo *varinfo = scope_find(var->var.scope, var->var.name, NULL);
        assert(varinfo != NULL);

        VarDecl *decl = new_vardecl(varinfo);
        decl->init_stmt = new_stmt_expr(size);

        if (decls == NULL)
          decls = new_vector();
        vec_push(decls, decl);
      }
    }
#endif

    VarInfo *varinfo = add_var_to_scope(curscope, tinfo->ident, type, tinfo->storage, false);
    if (type->kind != TY_FUNC) {
      Initializer *init = match(TK_ASSIGN) ? parse_initializer() : NULL;

      if (type->kind == TY_AUTO) {
        type = NULL;
        if (init != NULL && init->kind == IK_MULTI && init->multi->len == 1)
          init = init->multi->data[0];
        if (init == NULL) {
          parse_error(PE_NOFATAL, tinfo->ident, "auto type must have initializer");
        } else if (init->kind != IK_SINGLE) {
          parse_error(PE_NOFATAL, tinfo->ident, "auto type must have single initializer");
        } else {
          type = init->single->type;
          switch (type->kind) {
          case TY_FUNC:
            type = ptrof(type);  // Function pointer.
            break;
          case TY_VOID: assert(false); break;
          default: break;
          }
        }

        if (type == NULL) {
          type = &tyInt;  // Dummy
          init = NULL;
        }
      }

      init = check_vardecl(&type, tinfo->ident, tinfo->storage, init);
      varinfo->type = type;  // type might be changed.
      if (init != NULL && !(tinfo->storage & (VS_STATIC | VS_EXTERN))) {
        VarDecl *decl = new_vardecl(varinfo);
        if (decls == NULL)
          decls = new_vector();
        vec_push(decls, decl);
      }
    }
  } while (match(TK_COMMA));
  return decls;
}

static bool parse_vardecl(Vector *stmts) {
  ParsedTypeInfo tinfo;
  Type *type = parse_var_def(NULL, &tinfo);
  if (type == NULL)
    return false;

  if (tinfo.ident == NULL) {
    if ((type->kind == TY_STRUCT ||
         (type->kind == TY_FIXNUM && type->fixnum.kind == FX_ENUM)) &&
        match(TK_SEMICOL)) {
      // Just struct/union or enum definition.
    } else {
      parse_error(PE_NOFATAL, NULL, "ident expected");
      return false;
    }
  } else {
    Vector *decls = parse_vardecl_cont(type, &tinfo);
    if (consume(TK_SEMICOL, "`;' expected")) {
      if (decls != NULL) {
        if (!is_global_scope(curscope))
          construct_initializing_stmts(decls);
        for (int i = 0, len = decls->len; i < len; ++i) {
          VarDecl *vardecl = decls->data[i];
          Stmt *stmt = new_stmt_vardecl(vardecl);
          vec_push(stmts, stmt);
        }
      }
    }
  }
  return true;
}

static Stmt *parse_if(const Token *tok) {
  consume(TK_LPAR, "`(' expected");
  Expr *cond = parse_expr();
  cond = used_as_value(cond);
  consume(TK_RPAR, "`)' expected");
  Stmt *tblock = parse_stmt();
  Stmt *fblock = NULL;
  if (match(TK_ELSE)) {
    fblock = parse_stmt();
  }
  Stmt *stmt = new_stmt_if(tok, make_cond(cond), tblock, fblock);
  tblock->parent = stmt;
  if (fblock != NULL)
    fblock->parent = stmt;
  return stmt;
}

static Stmt *parse_switch(const Token *tok) {
  consume(TK_LPAR, "`(' expected");
  Expr *value = parse_expr();
  value = used_as_value(value);
  if (!is_fixnum(value->type)) {
    parse_error(PE_NOFATAL, value->token, "must be integer");
    value = new_expr_fixlit(&tyInt, value->token, 0);  // Dummy.
  }
  consume(TK_RPAR, "`)' expected");

  Stmt *stmt = new_stmt_switch(tok, value);
  SAVE_LOOP_SCOPE(save, stmt, NULL);
  loop_scope.swtch = stmt;

  Stmt *body = parse_stmt();
  body->parent = stmt;
  stmt->switch_.body = body;

  RESTORE_LOOP_SCOPE(save);

  return stmt;
}

static inline int find_case(Stmt *swtch, Fixnum v) {
  Vector *cases = swtch->switch_.cases;
  for (int i = 0, len = cases->len; i < len; ++i) {
    Stmt *c = cases->data[i];
    if (c->case_.value == NULL)
      continue;
    if (c->case_.value->fixnum == v)
      return i;
  }
  return -1;
}

static Stmt *parse_case(const Token *tok) {
  Expr *value = NULL;
  if (tok->kind == TK_CASE)
    value = parse_const_fixnum();
  consume(TK_COLON, "`:' expected");

  Stmt *swtch = loop_scope.swtch;
  if (swtch == NULL) {
    parse_error(PE_NOFATAL, tok, "`%s' cannot use outside of `switch`",
                tok->kind == TK_CASE ? "case" : "default");
    return parse_stmt();  // Expecting next statement.
  }

  if (value != NULL) {
    if (find_case(swtch, value->fixnum) >= 0) {
      parse_error(PE_NOFATAL, tok, "case value `%" PRId64 "' already defined", value->fixnum);
    } else {
      value = make_cast(swtch->switch_.value->type, value->token, value, false);
    }
  } else {
    if (swtch->switch_.default_ != NULL) {
      parse_error(PE_NOFATAL, tok, "`default' already defined in `switch'");
    }
  }

  Stmt *stmt = new_stmt_case(tok, swtch, value);
  vec_push(swtch->switch_.cases, stmt);
  if (tok->kind == TK_DEFAULT)
    swtch->switch_.default_ = stmt;

  Stmt *next = parse_stmt();
  if (next == NULL) {
    parse_error(PE_NOFATAL, tok, "statement expected");
    next = new_stmt(ST_EMPTY, tok);  // Dummy
  }
  next->parent = stmt;
  stmt->case_.stmt = next;

  return stmt;
}

static Stmt *parse_while(const Token *tok) {
  consume(TK_LPAR, "`(' expected");
  Expr *cond = make_cond(parse_expr());
  cond = used_as_value(cond);
  consume(TK_RPAR, "`)' expected");

  Stmt *stmt = new_stmt_while(tok, cond, NULL);

  SAVE_LOOP_SCOPE(save, stmt, stmt);

  Stmt *body = parse_stmt();
  body->parent = stmt;
  stmt->while_.body = body;

  RESTORE_LOOP_SCOPE(save);

  return stmt;
}

static Stmt *parse_do_while(const Token *tok) {
  Stmt *stmt = new_stmt(ST_DO_WHILE, tok);

  SAVE_LOOP_SCOPE(save, stmt, stmt);

  Stmt *body = parse_stmt();
  body->parent = stmt;
  stmt->while_.body = body;

  RESTORE_LOOP_SCOPE(save);

  consume(TK_WHILE, "`while' expected");
  consume(TK_LPAR, "`(' expected");
  Expr *cond = parse_expr();
  cond = used_as_value(cond);
  stmt->while_.cond = make_cond(cond);
  consume(TK_RPAR, "`)' expected");
  consume(TK_SEMICOL, "`;' expected");
  return stmt;
}

static Stmt *parse_for(const Token *tok) {
  consume(TK_LPAR, "`(' expected");
  Expr *pre = NULL;
  Scope *scope = NULL;
  Stmt *block = NULL;  // Implicit block is created if variable declaration exists.
  if (!match(TK_SEMICOL)) {
    ParsedTypeInfo tinfo;
    Type *type = parse_var_def(NULL, &tinfo);
    if (type != NULL) {
      if (tinfo.ident == NULL) {
        parse_error(PE_NOFATAL, NULL, "ident expected");
      } else {
        scope = enter_scope(curfunc);
        block = new_stmt_block(tok, scope);

        Vector *decls = parse_vardecl_cont(type, &tinfo);
        if (decls != NULL) {
          Vector *stmts = block->block.stmts;
          construct_initializing_stmts(decls);
          for (int i = 0, len = decls->len; i < len; ++i) {
            VarDecl *vardecl = decls->data[i];
            Stmt *decl = new_stmt_vardecl(vardecl);
            decl->parent = block;
            vec_push(stmts, decl);
          }
        }
      }
    } else {
      pre = parse_expr();
    }
    consume(TK_SEMICOL, "`;' expected");
  }

  Expr *cond = NULL;
  Expr *post = NULL;
  if (!match(TK_SEMICOL)) {
    Expr *e = parse_expr();
    e = used_as_value(e);
    cond = make_cond(e);
    consume(TK_SEMICOL, "`;' expected");
  }
  if (!match(TK_RPAR)) {
    post = parse_expr();
    consume(TK_RPAR, "`)' expected");
  }

  Stmt *stmt = new_stmt_for(tok, pre, cond, post, NULL);

  SAVE_LOOP_SCOPE(save, stmt, stmt);

  Stmt *body = parse_stmt();
  body->parent = stmt;
  stmt->for_.body = body;

  RESTORE_LOOP_SCOPE(save);

  if (scope != NULL) {
    assert(block != NULL);
    stmt->parent = block;
    vec_push(block->block.stmts, stmt);
    stmt = block;
    exit_scope();
  }
  return stmt;
}

static inline Stmt *parse_break_continue(enum StmtKind kind, const Token *tok) {
  consume(TK_SEMICOL, "`;' expected");
  Stmt *target = kind == ST_BREAK ? loop_scope.break_ : loop_scope.continu;
  if (target == NULL) {
    parse_error(PE_NOFATAL, tok, "`%.*s' cannot be used outside of loop",
                (int)(tok->end - tok->begin), tok->begin);
    return NULL;
  }
  Stmt *stmt = new_stmt(kind, tok);
  stmt->break_.target = target;
  return stmt;
}

static inline Stmt *parse_goto(const Token *tok) {
  Token *label = consume(TK_IDENT, "label for goto expected");
  consume(TK_SEMICOL, "`;' expected");

  Stmt *stmt = new_stmt_goto(tok, label);
  if (label != NULL)
    add_func_goto_label(label, stmt, NULL);
  return stmt;
}

static inline Stmt *parse_label(const Token *tok) {
  Stmt *next = parse_stmt();
  if (next == NULL) {
    parse_error(PE_NOFATAL, NULL, "statement expected");
    next = new_stmt(ST_EMPTY, tok);  // Dummy
  }
  Stmt *stmt = new_stmt_label(tok, next);
  next->parent = stmt;
  add_func_goto_label(tok, NULL, stmt);
  return stmt;
}

static inline Stmt *parse_return(const Token *tok) {
  Expr *val = NULL;
  if (!match(TK_SEMICOL)) {
    val = parse_expr();
    consume(TK_SEMICOL, "`;' expected");
    val = used_as_value(val);
    val = str_to_char_array_var(curscope, val);
  }

  assert(curfunc != NULL);
  Type *rettype = curfunc->type->func.ret;
  if (val == NULL) {
    if (rettype->kind != TY_VOID)
      parse_error(PE_NOFATAL, tok, "`return' required a value");
  } else {
    if (rettype->kind == TY_VOID) {
      if (val->type->kind == TY_VOID) {
        // Allow `return void_fnc();`.
        parse_error(PE_WARNING, val->token, "`return' with void value");
      } else {
        parse_error(PE_NOFATAL, val->token, "void function `return' a value");
      }
    } else {
      val = make_cast(rettype, val->token, val, false);
    }
  }

  return new_stmt_return(tok, val);
}

static Vector *parse_asm_arg(bool param) {
  const Token *constraint = match(TK_STR);
  if (constraint == NULL)
    return NULL;

  Vector *result = new_vector();
  for (;;) {
    if (param && consume(TK_LPAR, "`(' expected")) {
      Expr *expr = parse_assign();
      consume(TK_RPAR, "`)' expected");

      AsmArg *arg = calloc_or_die(sizeof(*arg));
      arg->constraint = constraint;
      arg->expr = expr;
      used_as_value(expr);
      vec_push(result, arg);
    }

    if (!match(TK_COMMA))
      break;

    constraint = consume(TK_STR, "string literal expected");
  }
  return result;
}

static Stmt *parse_asm(const Token *tok) {
  int flag = 0;
  if (match(TK_VOLATILE))
    flag |= ASM_VOLATILE;

  consume(TK_LPAR, "`(' expected");

  Expr *str = parse_assign();
  if (str == NULL || str->kind != EX_STR) {
    parse_error(PE_NOFATAL, str != NULL ? str->token : NULL, "`__asm' expected string literal");
    return new_stmt(ST_EMPTY, tok);
  }

  Vector *outputs = NULL, *inputs = NULL, *clobbers, *labels;
  if (match(TK_COLON)) {
    outputs = parse_asm_arg(true);
    if (match(TK_COLON)) {
      inputs = parse_asm_arg(true);
      if (match(TK_COLON)) {
        clobbers = parse_asm_arg(false);
        if (match(TK_COLON)) {
          labels = parse_asm_arg(false);
        }
      }
    }
  }
  UNUSED(clobbers);  // TODO
  UNUSED(labels);  // TODO

  consume(TK_RPAR, "`)' expected");
  consume(TK_SEMICOL, "`;' expected");

  Vector *templates = new_vector();
  unsigned long param_count = 0;
  if (outputs != NULL)
    param_count += outputs->len;
  if (inputs != NULL)
    param_count += inputs->len;
  {
    char *buf = str->str.buf;  // Buffer will be modified.
    size_t len = str->str.len;
    char *top = buf, *p = top;
    for (;;) {
      char *q = strchr(p, '%');
      if (q == NULL) {
        if (*top != '\0')
          vec_push(templates, top);
        break;
      }

      ++q;
      if (*q == '%') {  // %% => %
        memmove(q, q + 1, len - (q - top - 1));
        p = q;
      } else {
        char *r;
        unsigned long index = strtoul(q, &r, 10);
        if (r > q) {  // Number:
          if (index >= param_count) {
            parse_error(PE_NOFATAL, str->token, "invalid index");
          }
          q[-1] = '\0';
          vec_push(templates, top);
          vec_push(templates, (void*)(uintptr_t)index);
          len -= r - top;
          top = p = r;
        } else {  // Non-template: ignored.
          p = q;
        }
      }
    }
  }

  return new_stmt_asm(tok, templates, outputs, inputs, flag);
}

static inline const Token *parse_stmts(Stmt *parent, Vector *stmts) {
  for (;;) {
    parsing_stmt = true;
    if (parse_vardecl(stmts))
      continue;

    Stmt *stmt = parse_stmt();
    if (stmt == NULL) {
      Token *tok = match(TK_RBRACE);
      if (tok == NULL)
        parse_error(PE_NOFATAL, NULL, "`}' expected");
      return tok;
    }
    stmt->parent = parent;
    vec_push(stmts, stmt);
  }
}

// <compound-statement> ::= { {<declaration>}* {<statement>}* }
Stmt *parse_block(const Token *tok, Scope *scope) {
  if (scope == NULL)
    scope = enter_scope(curfunc);
  Stmt *stmt = new_stmt_block(tok, scope);
  stmt->block.rbrace = parse_stmts(stmt, stmt->block.stmts);
  exit_scope();
  return stmt;
}

// <statement> ::= <labeled-statement>
//               | <expression-statement>
//               | <compound-statement>
//               | <selection-statement>
//               | <iteration-statement>
//               | <jump-statement>
// <labeled-statement> ::= <identifier> : <statement>
//                       | case <constant-expression> : <statement>
//                       | default : <statement>
// <expression-statement> ::= {<expression>}? ;
// <selection-statement> ::= if ( <expression> ) <statement>
//                         | if ( <expression> ) <statement> else <statement>
//                         | switch ( <expression> ) <statement>
// <iteration-statement> ::= while ( <expression> ) <statement>
//                         | do <statement> while ( <expression> ) ;
//                         | for ( {<expression>}? ; {<expression>}? ; {<expression>}? ) <statement>
// <jump-statement> ::= goto <identifier> ;
//                    | continue ;
//                    | break ;
//                    | return {<expression>}? ;
static Stmt *parse_stmt(void) {
  parsing_stmt = true;
  Token *tok = match(-1);
  switch (tok->kind) {
  case TK_RBRACE:
  case TK_EOF:
    unget_token(tok);
    return NULL;
  case TK_IDENT:
    if (match(TK_COLON))
      return parse_label(tok);
    break;
  case TK_CASE: case TK_DEFAULT:
    return parse_case(tok);
  case TK_SEMICOL:  return new_stmt(ST_EMPTY, tok);
  case TK_LBRACE:  return parse_block(tok, NULL);
  case TK_IF:  return parse_if(tok);
  case TK_SWITCH:  return parse_switch(tok);
  case TK_WHILE:  return parse_while(tok);
  case TK_DO:  return parse_do_while(tok);
  case TK_FOR:  return parse_for(tok);
  case TK_BREAK: case TK_CONTINUE:
    return parse_break_continue(tok->kind == TK_BREAK ? ST_BREAK : ST_CONTINUE, tok);
  case TK_GOTO:  return parse_goto(tok);
  case TK_RETURN:  return parse_return(tok);
  case TK_ASM:  return parse_asm(tok);
  default:  break;
  }

  unget_token(tok);

  // expression statement.
  Expr *val = parse_expr();
  if (val == NULL)
    val = new_expr_fixlit(&tyInt, tok, 0);  // Dummy
  consume(TK_SEMICOL, "`;' expected");
  return new_stmt_expr(str_to_char_array_var(curscope, val));
}

static Table *parse_attribute(Table *attributes) {  // <Expr*>
  // __attribute__((name1, name2(p, q, ...), ...))

  if (consume(TK_LPAR, "`(' expected") == NULL || consume(TK_LPAR, "`(' expected") == NULL) {
    match(TK_RPAR);
    match(TK_RPAR);
    return NULL;
  }

  for (;;) {
    if (match(TK_RPAR))
      break;

    const Token *name = consume(TK_IDENT, "attribute name expected");
    if (name == NULL)
      break;

    Vector *params = NULL;
    if (match(TK_LPAR)) {
      params = new_vector();
      if (!match(TK_RPAR)) {
        for (;;) {
          Scope *bak_curscope = curscope;
          curscope = NULL;
          Expr *expr = parse_assign();
          curscope = bak_curscope;
          if (expr != NULL)
            vec_push(params, expr);
          if (!match(TK_COMMA)) {
            if (!match(TK_RPAR))
              parse_error(PE_NOFATAL, NULL, "`)' expected");
            break;
          }
        }
      }
    }
    if (attributes == NULL)
      attributes = alloc_table();
    table_put(attributes, name->ident, params);

    if (!match(TK_COMMA)) {
      if (!match(TK_RPAR))
        parse_error(PE_NOFATAL, NULL, "`)' expected");
      break;
    }
  }

  consume(TK_RPAR, "`)' expected");
  return attributes;
}

Table *parse_attributes(Table *attributes) {
  for (;;) {
    if (match(TK_ATTRIBUTE)) {
      attributes = parse_attribute(attributes);
    } else if (match(TK_NORETURN)) {
      if (attributes == NULL)
        attributes = alloc_table();
      table_put(attributes, alloc_cname("noreturn"), NULL);
    } else {
      break;
    }
  }
  return attributes;
}

#ifndef __NO_VLA
static inline void modify_funparam_vla_type(Type *type, Scope *scope) {
  if (type->kind == TY_ARRAY && type->pa.vla != NULL) {
    type->kind = TY_PTR;  // array_to_ptr, but must apply the change to the original type.
  }

  for (;;) {
    if (!ptr_or_array(type))
      break;
    if (type->pa.vla != NULL) {
      assert(type->pa.vla->kind == EX_VAR);
      type->pa.vla->var.scope = scope;  // Fix scope, which set in `parse_direct_declarator_suffix()`
    }
    type = type->pa.ptrof;
  }
}
#endif

static bool is_weak_attr(Table *attributes) {
  return /*attributes != NULL &&*/
         (table_try_get(attributes, alloc_cname("weak"), NULL) ||
          table_try_get(attributes, alloc_cname("__weak__"), NULL));
}

static void handle_attribute(
    VarInfo *varinfo, Table *attributes, Initializer *init, const Token *err_token) {
  if (is_weak_attr(attributes))
    varinfo->storage |= VS_WEAK;

  const Name *alias_name = alloc_name("__alias__", NULL, false);
  const Name *alias_name2 = alloc_name("alias", NULL, false);
  Vector *exprs;
  if (table_try_get(attributes, alias_name, (void**)&exprs) ||
      table_try_get(attributes, alias_name2, (void**)&exprs)) {
    const Expr *target;
    if (init != NULL) {
      parse_error(PE_NOFATAL, init->token, "__alias__ with initializer");
      return;
    }
    if (exprs->len != 1 ||
        (target = exprs->data[0], target->kind != EX_STR || target->str.kind != STR_CHAR)) {
      const Token *tok = exprs->len > 0 ? ((Expr*)exprs->data[0])->token : err_token;
      parse_error(PE_NOFATAL, tok, "string expected for `__alias__'");
      return;
    }

    const Name *target_name = alloc_name(target->str.buf, NULL, false);
    VarInfo *target_varinfo = scope_find(global_scope, target_name, NULL);
    if (target_varinfo == NULL) {
      parse_error(PE_NOFATAL, target->token, "`%.*s' undefined", NAMES(target_name));
      return;
    }

    // Add referred.
    Vector *refs = varinfo->global.referred_globals;
    if (refs == NULL)
      varinfo->global.referred_globals = refs = new_vector();
    vec_push(refs, target_varinfo);

    varinfo->global.alias = target_varinfo;
    target_varinfo->storage |= VS_USED;  // TODO!
  }
}

// <function-definition> ::= {<declaration-specifier>}* <declarator> {<declaration>}* <compound-statement>
static Declaration *parse_defun(Type *functype, int storage, Token *ident, const Token *tok,
                                Table *attributes) {
  assert(functype->kind == TY_FUNC);

  const Vector *param_vars = functype->func.param_vars;
  if (functype->func.params == NULL) {  // Old-style
    // Treat it as a zero-parameter function.
    functype->func.params = new_vector();
    functype->func.vaargs = false;
    param_vars = new_vector();
  }

  Function *func = define_func(functype, ident, param_vars, storage, attributes);
  VarInfo *varinfo = scope_find(global_scope, ident->ident, NULL);
  assert(varinfo != NULL);
  if (varinfo->global.func != NULL) {
    parse_error(PE_NOFATAL, ident, "`%.*s' function already defined", NAMES(func->ident->ident));
  } else {
    varinfo->global.func = func;
  }
  if (attributes != NULL)
    handle_attribute(varinfo, attributes, NULL, ident);

  assert(curfunc == NULL);
  assert(is_global_scope(curscope));
  curfunc = func;
  static_vars = func->static_vars = new_vector();
  curvarinfo = varinfo;
  Vector *top_vars = new_vector();
  ensure_type_info(functype->func.ret, ident, curscope, true);
  for (int i = 0; i < param_vars->len; ++i) {
    VarInfo *vi = param_vars->data[i];
    vec_push(top_vars, vi);
    ensure_type_info(vi->type, vi->ident, curscope, true);
  }
  func->scopes = new_vector();
  Scope *scope = enter_scope(func);
  scope->vars = top_vars;

#ifndef __NO_VLA
  Vector *vla_inits = NULL;  // <Stmt*>
  for (int i = 0; i < top_vars->len; ++i) {
    VarInfo *vi = top_vars->data[i];
    Type *type = vi->type;
    Expr *vla_size = calc_vla_size(type);
    if (vla_size != NULL) {
      if (vla_inits == NULL)
        vla_inits = new_vector();
      vec_push(vla_inits, new_stmt_expr(vla_size));
    }
    modify_funparam_vla_type(type, scope);
  }
#endif

  func->body_block = parse_block(tok, scope);
  assert(is_global_scope(curscope));
  curfunc = NULL;
  static_vars = NULL;
  curvarinfo = NULL;

#ifndef __NO_VLA
  if (vla_inits != NULL) {
    assert(func->body_block->kind == ST_BLOCK);
    assert(func->body_block->block.stmts != NULL);
    Vector *stmts = func->body_block->block.stmts;
    for (int i = vla_inits->len; i-- > 0; ) {
      Stmt *stmt = vla_inits->data[i];
      vec_insert(stmts, 0, stmt);
    }
  }
#endif

  check_goto_labels(func);
  check_func_reachability(func);

  if (cc_flags.warn.unused_variable)
    check_unused_variables(func);

  Declaration *decl = new_decl_defun(func);
  varinfo->global.funcdecl = decl;
  return decl;
}

// <declaration> ::=  {<declaration-specifier>}+ {<init-declarator>}* ;
static void parse_global_var_decl(ParsedTypeInfo *tinfo, Type *type, Vector *decls) {
  UNUSED(decls);
  Table *attributes = tinfo->attributes;
  for (;;) {
    attributes = parse_attributes(attributes);

#ifndef __NO_VLA
    if (type->kind == TY_ARRAY && type->pa.vla != NULL)
      type = array_to_ptr(type);
#endif

    if (tinfo->storage & VS_TYPEDEF) {
      if (tinfo->ident != NULL) {
#ifndef __NO_VLA
        if (is_global_scope(curscope) && type->kind == TY_PTR && type->pa.vla != NULL)
          parse_error(PE_NOFATAL, tinfo->ident, "variable length array cannot use in global scope");
#endif
        def_type(type, tinfo->ident);
      }
    } else if (type->kind == TY_VOID) {
      if (tinfo->ident != NULL)
        parse_error(PE_NOFATAL, tinfo->ident, "`void' not allowed");
    } else {
      Initializer *init = NULL;
      VarInfo *varinfo = NULL;
      if (type->kind == TY_FUNC) {
        // Prototype declaration.
        if (tinfo->ident == NULL) {
          parse_error(PE_NOFATAL, NULL, "ident expected");
        } else {
          Function *func = define_func(type, tinfo->ident, type->func.param_vars, tinfo->storage,
                                       attributes);
          varinfo = scope_find(global_scope, tinfo->ident->ident, NULL);
          assert(varinfo != NULL);

          Declaration *decl = new_decl_defun(func);
          varinfo->global.funcdecl = decl;

          if ((tinfo->storage & (VS_INLINE | VS_EXTERN)) == (VS_INLINE | VS_EXTERN)) {
            // To make inline function output, add to declarations.
            if ((varinfo->storage & (VS_INLINE | VS_STATIC | VS_EXTERN)) == VS_INLINE) {
              varinfo->storage |= VS_EXTERN;
            }
          }
        }
        // Check LBRACE?
      } else {
        bool has_initializer = match(TK_ASSIGN) != NULL;
        if (tinfo->ident != NULL) {
          varinfo = add_var_to_scope(global_scope, tinfo->ident, type, tinfo->storage,
                                     !has_initializer);
          if (same_type(type, varinfo->type))
            init = varinfo->global.init;
          else
            varinfo = NULL;
        }

        assert(curvarinfo == NULL);
        if (has_initializer) {
          curvarinfo = varinfo;
          init = parse_initializer();
        }

        if (tinfo->ident != NULL && varinfo != NULL) {
          varinfo->global.init = check_vardecl(&type, tinfo->ident, tinfo->storage, init);
          varinfo->type = type;  // type might be changed.
        }
        curvarinfo = NULL;
      }

      if (varinfo != NULL && attributes != NULL)
        handle_attribute(varinfo, attributes, init, tinfo->ident);
    }

    if (!match(TK_COMMA))
      break;

    attributes = NULL;  // TODO: Confirm.

    // Next declaration.
    type = parse_declarator(tinfo->rawType, tinfo);
  }
  consume(TK_SEMICOL, "`;' or `,' expected");
}

// <external-declaration> ::= <function-definition>
//                          | <declaration>
static Declaration *parse_declaration(Vector *decls) {
  bool consumed_empty = false;
  while (match(TK_SEMICOL))
    consumed_empty = true;
  if (consumed_empty)
    return NULL;  // Allow empty declaration.

  Token *tok;
  if ((tok = match(TK_ASM)) != NULL) {
    Stmt *asm_ = parse_asm(tok);
    return new_decl_asm(tok, &asm_->asm_);
  }

  ParsedTypeInfo tinfo;
  Type *type = parse_var_def(NULL, &tinfo);
  if (type != NULL) {
    if (tinfo.ident == NULL) {
      if ((type->kind == TY_STRUCT ||
           (type->kind == TY_FIXNUM && type->fixnum.kind == FX_ENUM)) &&
          match(TK_SEMICOL)) {
        // Just struct/union or enum definition.
      } else {
        parse_error(PE_NOFATAL, NULL, "ident expected");
      }
      return NULL;
    }

    if (type->kind == TY_FUNC) {
      if (tinfo.storage & VS_TYPEDEF) {
        consume(TK_SEMICOL, "`;' expected");
        assert(tinfo.ident != NULL);
        def_type(type, tinfo.ident);
        return NULL;
      }

      const Token *tok = match(TK_LBRACE);
      if (tok != NULL)
        return parse_defun(type, tinfo.storage, tinfo.ident, tok, tinfo.attributes);
      // Function prototype declaration:
      // Join with global variable declaration to handle multiple prototype declarations.
    }

    parse_global_var_decl(&tinfo, type, decls);
    return NULL;
  }
  parse_error(PE_NOFATAL, NULL, "unexpected token");
  match(-1);  // Drop the token.
  return NULL;
}

// <translation-unit> ::= {<external-declaration>}*
void parse(Vector *decls) {
  curscope = global_scope;

  while (!match(TK_EOF)) {
    Declaration *decl = parse_declaration(decls);
    if (decl != NULL)
      vec_push(decls, decl);
  }

  propagate_var_used();

#ifdef NO_DESTRUCTOR
  modify_dtor_func(decls);
#endif
}
