#include "../../config.h"
#include "codegen.h"

#include <assert.h>
#include <limits.h>  // CHAR_BIT
#include <stdbool.h>
#include <stdlib.h>  // qsort
#include <string.h>

#include "ast.h"
#include "be_aux.h"
#include "cc_misc.h"  // is_function_omitted
#include "fe_misc.h"  // curfunc, curscope
#include "initializer.h"
#include "ir.h"
#include "optimize.h"
#include "regalloc.h"
#include "table.h"
#include "type.h"
#include "util.h"
#include "var.h"

void set_curbb(BB *bb) {
  assert(bb != NULL);
  assert(curfunc != NULL);
  if (curbb != NULL)
    curbb->next = bb;
  curbb = bb;
  vec_push(((FuncBackend*)curfunc->extra)->bbcon, bb);
}

//

static BB *s_break_bb;
static BB *s_continue_bb;

static void pop_break_bb(BB *save) {
  s_break_bb = save;
}

static void pop_continue_bb(BB *save) {
  s_continue_bb = save;
}

static BB *push_continue_bb(BB **save) {
  *save = s_continue_bb;
  BB *bb = new_bb();
  s_continue_bb = bb;
  return bb;
}

static BB *push_break_bb(BB **save) {
  *save = s_break_bb;
  BB *bb = new_bb();
  s_break_bb = bb;
  return bb;
}

static inline VarInfo *prepare_retvar(Function *func) {
  // Insert vreg for return value pointer into top of the function scope.
  static const char RETBUFPTR[] = ".._RETBUFPTR";
  Type *rettype = func->type->func.ret;
  const Token *retval_token = alloc_ident(alloc_cname(RETBUFPTR), NULL, RETBUFPTR, NULL);
  Type *retptrtype = ptrof(rettype);
  Scope *top_scope = func->scopes->data[0];
  VarInfo *varinfo = scope_add(top_scope, retval_token, retptrtype, 0);
  VReg *vreg = add_new_vreg(varinfo->type);
  vreg->flag |= VRF_PARAM;
#if EXTRA_RETURN_STRUCT_REGISTER
  vreg->reg_param_index = kArchSetting.max_reg_args[GPREG];
#else
  vreg->reg_param_index = 0;
#endif
  varinfo->local.vreg = vreg;
  FuncBackend *fnbe = func->extra;
  fnbe->struct_retvar = varinfo;
  return varinfo;
}

static void alloc_variable_registers(Function *func) {
  assert(func->type->kind == TY_FUNC);

  for (int i = 0; i < func->scopes->len; ++i) {
    Scope *scope = func->scopes->data[i];
    for (int j = 0; j < scope->vars->len; ++j) {
      VarInfo *varinfo = scope->vars->data[j];
      if (!is_local_storage(varinfo)) {
        // Static entity is allocated in global, not on stack.
        // Extern doesn't have its entity.
        // Enum members are replaced to constant value.
        continue;
      }

      varinfo->local.vreg = NULL;
      varinfo->local.frameinfo = NULL;
      Type *type = varinfo->type;
#if STRUCT_ARG_AS_POINTER
      if (varinfo->storage & VS_PARAM && type->kind == TY_STRUCT && !is_small_struct(type))
        type = &tyVoidPtr;
#endif
      if (!is_prim_type(type)) {
        FrameInfo *fi = calloc_or_die(sizeof(*fi));
        fi->size = type_size(type);
        fi->offset = 0;
        varinfo->local.frameinfo = fi;
        continue;
      }

      const int storage = varinfo->storage;
      VReg *vreg = add_new_vreg_with_storage(type, storage);
      if (storage & VS_REF_TAKEN)
        vreg->flag |= VRF_REF;
      if (type->qualifier & TQ_VOLATILE)
        vreg->flag |= (storage & VS_REGISTER) ? (VRF_VOLATILEREG | VRF_NO_SPILL) : VRF_VOLATILE;
      varinfo->local.vreg = vreg;
      varinfo->local.frameinfo = &vreg->frame;
    }
  }

  int regcount[2] = {0, 0};

  // Handle if return value is on the stack.
  const Type *rettype = func->type->func.ret;
  if (rettype->kind == TY_STRUCT && !is_small_struct(rettype) && !is_phantom_struct(rettype)) {
    prepare_retvar(func);
#if !EXTRA_RETURN_STRUCT_REGISTER
    ++regcount[GPREG];
#endif
  }

  // Count register parameters, or set flag.
  const Vector *params = func->params;
  if (params != NULL) {
    for (int i = 0; i < params->len; ++i) {
      VarInfo *varinfo = params->data[i];
      VReg *vreg = varinfo->local.vreg;
      if (vreg != NULL) {
        vreg->flag |= VRF_PARAM;
        bool is_flo = (vreg->flag & VRF_FLONUM) != 0;
        int *p = &regcount[is_flo];
#if USE_GP_FOR_OVERFLOW_FP
        int extra_flag = 0;
        if (is_flo && *p >= kArchSetting.max_reg_args[is_flo]) {
          is_flo = false;
          p = &regcount[GPREG];
          extra_flag = VRF_FP_GP_PARAM;
        }
#endif
        if (*p < kArchSetting.max_reg_args[is_flo]) {
          vreg->reg_param_index = (*p)++;
#if USE_GP_FOR_OVERFLOW_FP
          vreg->flag |= extra_flag;
#endif
        } else {
          vreg->flag |= VRF_STACK_PARAM;
        }
      } else if (is_small_struct(varinfo->type)) {
        // Small struct params consume GP registers even without a vreg.
        size_t n = (type_size(varinfo->type) + (TARGET_POINTER_SIZE - 1)) / TARGET_POINTER_SIZE;
        if (regcount[GPREG] + (int)n <= kArchSetting.max_reg_args[GPREG]) {
          regcount[GPREG] += (int)n;
        }
      }
    }
  }
}

int enumerate_register_params(Function *func, const int max_reg[2], RegParamInfo *args) {
#define IS_INLINING(fnbe)  ((fnbe)->inline_result_dst != NULL)

#define HANDLE_RETURN_STRUCT_REGISTER(idx) do { \
    const Type *rettype = func->type->func.ret; \
    if (rettype->kind == TY_STRUCT && !is_small_struct(rettype)) { \
      FuncBackend *fnbe = func->extra; \
      if (!IS_INLINING(fnbe)) { \
        RegParamInfo *p = &args[total++]; \
        VarInfo *vi = fnbe->struct_retvar; \
        assert(vi != NULL && is_local_storage(vi)); \
        p->vreg = vi->local.vreg; \
        assert(p->vreg != NULL); \
        p->index = idx; \
        ++arg_count[GPREG]; \
        ++reg_index[GPREG]; \
      } \
    } \
  } while (0)

  int arg_count[2] = {0, 0};
  int reg_index[2] = {0, 0};
  int total = 0;

#if !EXTRA_RETURN_STRUCT_REGISTER
  HANDLE_RETURN_STRUCT_REGISTER(0);
#endif

  const Vector *params = func->params;
  if (params != NULL) {
    for (int i = 0, len = params->len; i < len; ++i) {
      const VarInfo *varinfo = params->data[i];
      const Type *type = varinfo->type;
      size_t n = 1;
      if (is_stack_param(type)) {
        if (is_small_struct(type)) {
          n = (type_size(type) + (TARGET_POINTER_SIZE - 1)) / TARGET_POINTER_SIZE;
        } else {
#if STRUCT_ARG_AS_POINTER
          type = &tyVoidPtr;
#else
          continue;
#endif
        }
      }
      bool is_flo = is_flonum(type);
      int regidx = reg_index[is_flo];
      int flag = 0;
      if (regidx + (int)n > max_reg[is_flo]) {
#if defined(USE_GP_FOR_OVERFLOW_FP)
        if (!is_flo)
          continue;
        is_flo = false;
        regidx = reg_index[GPREG];
        flag = REGPARAM_FP_AS_GP;
        assert(n == 1);
        if (regidx >= max_reg[GPREG])
          continue;
#else
        continue;
#endif
      }
      reg_index[is_flo] += n;

      assert(is_local_storage(varinfo));
      RegParamInfo *p = &args[total++];
      p->frameinfo = varinfo->local.frameinfo;
      p->vreg = varinfo->local.vreg;  // Might be NULL (small struct).
      p->index = regidx;
      p->flag = flag;
      arg_count[is_flo] += 1;
    }
  }

#if EXTRA_RETURN_STRUCT_REGISTER
  HANDLE_RETURN_STRUCT_REGISTER(kArchSetting.max_reg_args[GPREG]);
#endif
  return arg_count[GPREG] + arg_count[FPREG];
}

static enum VRegSize get_elem_vtype(const Type *type) {
  const size_t MAX_REG_SIZE = 8;  // TODO:

  size_t size = type_size(type);
  assert(size > 0);
  size_t align = align_size(type);
  size_t s = MIN(align, size);
  if (!IS_POWER_OF_2(s) || s > MAX_REG_SIZE) {
    for (s = MAX_REG_SIZE; s > 1; s >>= 1) {
      if (s <= size && size % s == 0)
        break;
    }
  }

  assert(s > 0);
  return most_significant_bit(s);
}

void gen_memcpy(const Type *type, VReg *dst, VReg *src) {
  size_t size = type_size(type);
  if (size == 0)
    return;
  enum VRegSize elem_vsize = get_elem_vtype(type);
  size_t count = size >> elem_vsize;
  assert(count > 0);
  if (count == 1) {
    VReg *tmp = new_ir_load(src, 0, elem_vsize, to_vflag(type))->dst;
    new_ir_store(dst, 0, tmp);
  } else {
    VReg *srcp = add_new_vreg(&tyVoidPtr);
    new_ir_mov(srcp, src);
    VReg *dstp = add_new_vreg(&tyVoidPtr);
    new_ir_mov(dstp, dst);

    enum VRegSize vsSize = to_vsize(&tySize);
    VReg *vcount = add_new_vreg(&tySize);
    new_ir_mov(vcount, new_const_vreg(count, vsSize, VRF_UNSIGNED));
    VReg *vadd = new_const_vreg(1 << elem_vsize, vsSize, VRF_UNSIGNED);

    BB *loop_bb = new_bb();
    set_curbb(loop_bb);
    VReg *tmp = new_ir_load(srcp, 0, elem_vsize, to_vflag(type))->dst;
    new_ir_mov(srcp, new_ir_bop(IR_ADD, srcp, vadd, srcp->vsize));  // srcp += elem_size
    new_ir_store(dstp, 0, tmp);
    new_ir_mov(dstp, new_ir_bop(IR_ADD, dstp, vadd, dstp->vsize));  // dstp += elem_size
    new_ir_mov(vcount, new_ir_bop(IR_SUB, vcount, new_const_vreg(1, vsSize, VRF_UNSIGNED),
                                  vcount->vsize));  // vcount -= 1
    new_ir_cjmp(vcount, new_const_vreg(0, vcount->vsize, VRF_UNSIGNED), COND_NE, loop_bb);
    set_curbb(new_bb());
  }
}

static void gen_clear(const Type *type, VReg *dst) {
  size_t size = type_size(type);
  if (size == 0)
    return;
  enum VRegSize elem_vtype = get_elem_vtype(type);
  size_t count = size >> elem_vtype;
  assert(count > 0);
  VReg *vzero = new_const_vreg(0, elem_vtype, VRF_UNSIGNED);
  if (count == 1) {
    new_ir_store(dst, 0, vzero);
  } else {
    VReg *dstp = add_new_vreg(&tyVoidPtr);
    new_ir_mov(dstp, dst);

    enum VRegSize vsSize = to_vsize(&tySize);
    VReg *vcount = add_new_vreg(&tySize);
    new_ir_mov(vcount, new_const_vreg(count, vsSize, VRF_UNSIGNED));
    VReg *vadd = new_const_vreg(1 << elem_vtype, vsSize, VRF_UNSIGNED);

    BB *loop_bb = new_bb();
    set_curbb(loop_bb);
    new_ir_store(dstp, 0, vzero);
    new_ir_mov(dstp, new_ir_bop(IR_ADD, dstp, vadd, dstp->vsize));  // dstp += elem_size
    new_ir_mov(vcount, new_ir_bop(IR_SUB, vcount, new_const_vreg(1, vsSize, VRF_UNSIGNED),
                                  vcount->vsize));  // vcount -= 1
    new_ir_cjmp(vcount, new_const_vreg(0, vcount->vsize, VRF_UNSIGNED), COND_NE, loop_bb);
    set_curbb(new_bb());
  }
}

static inline void gen_asm(Stmt *stmt) {
  VReg *output = NULL;
  Vector *registers = new_vector();
  if (stmt->asm_.outputs != NULL) {
    assert(stmt->asm_.outputs->len == 1);  // TODO: Handle multiple outputs.
    const AsmArg *arg = stmt->asm_.outputs->data[0];
    assert(arg->expr->kind == EX_VAR);
    output = gen_expr(arg->expr);
  }
  if (stmt->asm_.inputs != NULL) {
    for (int i = 0; i < stmt->asm_.inputs->len; ++i) {
      const AsmArg *arg = stmt->asm_.inputs->data[i];
      VReg *vreg = gen_expr(arg->expr);
      vec_push(registers, vreg);
    }
  }

  new_ir_asm(stmt->asm_.templates, output, registers);
}

VReg *gen_stmts(Vector *stmts) {
  assert(stmts != NULL);
  int len = stmts->len;
  VReg *result = NULL;
  if (len > 0) {
    int last = stmts->len - 1;
    for (int i = 0; i < last; ++i) {
      Stmt *stmt = stmts->data[i];
      if (stmt == NULL)
        continue;
      gen_stmt(stmt);
    }

    Stmt *last_stmt = stmts->data[last];
    if (last_stmt->kind == ST_EXPR)
      result = gen_expr(last_stmt->expr);
    else
      gen_stmt(last_stmt);
  }
  return result;
}

static inline void gen_expr_stmt(Expr *expr) {
  gen_expr(expr);
}

VReg *gen_block(Stmt *stmt) {
  assert(stmt->kind == ST_BLOCK);
  // AST may moved, so code generation traversal may differ from lexical scope chain.
  Scope *bak_curscope = curscope;
  if (stmt->block.scope != NULL)
    curscope = stmt->block.scope;
  VReg *result = gen_stmts(stmt->block.stmts);
  if (stmt->block.scope != NULL)
    curscope = bak_curscope;
  return result;
}

static inline void gen_return_small_struct(const Type *type, VReg *vreg) {
  const enum VRegSize kMaxVSize = VRegSize8;  // TODO: Max
  const size_t kMaxSize = 1U << kMaxVSize;
  size_t size = type_size(type);
  int n = (size + (kMaxSize - 1)) / kMaxSize;

  // Assumed little endian.
  for (int i = 0; i < n; ++i) {
    enum VRegSize vsize = size >= kMaxSize ? kMaxVSize :
        (enum VRegSize)(most_significant_bit(size) + (IS_POWER_OF_2(size) ? 0 : 1));
    size -= (size_t)1 << vsize;
    VReg *loaded = new_ir_load(vreg, i * kMaxSize, vsize, VRF_UNSIGNED)->dst;
    new_ir_result(loaded, i);
  }
}

static inline void gen_return(Stmt *stmt) {
  assert(curfunc != NULL);
  BB *bb = new_bb();
  FuncBackend *fnbe = curfunc->extra;
  Expr *val = stmt->return_.val;
  if (val != NULL) {
    VReg *vreg = gen_expr(val);
    const Type *type = val->type;
    if (!is_phantom_struct(type)) {
      VReg *result_dst = fnbe->inline_result_dst;
      if (result_dst == NULL) {  // Not inlining.
        if (is_small_struct(type)) {
          gen_return_small_struct(type, vreg);
        } else if (is_prim_type(type)) {
          new_ir_result(vreg, 0);
        } else if (type->kind != TY_VOID) {
          assert(fnbe->struct_retvar != NULL && is_local_storage(fnbe->struct_retvar));
          VReg *retval = fnbe->struct_retvar->local.vreg;
          assert(retval != NULL);
          gen_memcpy(type, retval, vreg);
          new_ir_result(retval, 0);  // Pointer is unsigned.
        }
      } else {  // Inlining.
        // Primitive            : return its value
        // Non-primitive(struct): return its pointer
        new_ir_mov(result_dst, vreg);
      }
    }
  }
  new_ir_result(NULL, -1);  // Indicate result is done.
  new_ir_jmp(fnbe->ret_bb);
  set_curbb(bb);
}

static inline void gen_if(Stmt *stmt) {
  Expr *cond = stmt->if_.cond;
  Stmt *tblock = stmt->if_.tblock;
  Stmt *fblock = stmt->if_.fblock;
  bool flip_order = false;
  if (cond->kind == EX_EXPECT) {
    Expr *value = cond->bop.lhs;
    Expr *expect = cond->bop.rhs;
    assert(expect->kind == EX_FIXNUM);
    if (fblock != NULL && expect->fixnum == 0) {
      flip_order = true;
      Stmt *tmp = tblock;
      tblock = fblock;
      fblock = tmp;
    }
    cond = value;
  }

  BB *tbb = new_bb();
  BB *fbb = new_bb();
  if (flip_order)
    gen_cond_jmp(cond, fbb, tbb);  // Swap jump target to flip the condition.
  else
    gen_cond_jmp(cond, tbb, fbb);
  set_curbb(tbb);
  gen_stmt(tblock);
  if (fblock == NULL) {
    set_curbb(fbb);
  } else {
    BB *nbb = new_bb();
    new_ir_jmp(nbb);
    set_curbb(fbb);
    gen_stmt(fblock);
    set_curbb(nbb);
  }
}

static int compare_cases(const void *pa, const void *pb) {
  Stmt *ca = *(Stmt**)pa;
  Stmt *cb = *(Stmt**)pb;
  if (ca->case_.value == NULL)
    return 1;
  if (cb->case_.value == NULL)
    return -1;
  Fixnum d = ca->case_.value->fixnum - cb->case_.value->fixnum;
  return d > 0 ? 1 : d < 0 ? -1 : 0;
}

static void gen_switch_cond_table_jump(Stmt *swtch, VReg *vreg, Stmt **cases, int len) {
  Fixnum min = (cases[0])->case_.value->fixnum;
  Fixnum max = (cases[len - 1])->case_.value->fixnum;
  Fixnum range = max - min + 1;

  BB **table = malloc_or_die(sizeof(*table) * range);
  Stmt *def = swtch->switch_.default_;
  BB *skip_bb = def != NULL ? def->case_.bb : swtch->switch_.break_bb;
  for (Fixnum i = 0; i < range; ++i)
    table[i] = skip_bb;
  for (int i = 0; i < len; ++i) {
    Stmt *c = cases[i];
    table[c->case_.value->fixnum - min] = c->case_.bb;
  }

  BB *nextbb = new_bb();
  VReg *val = vreg;
  if (min != 0)
    val = new_ir_bop(IR_SUB, vreg, new_const_vreg(min, vreg->vsize, vreg->flag & VRF_MASK),
                     vreg->vsize);
  if (!(val->flag & VRF_UNSIGNED))
    val = new_ir_cast(val, val->vsize, (val->flag & VRF_MASK) | VRF_UNSIGNED)->dst;
  new_ir_cjmp(val, new_const_vreg(max - min, val->vsize, val->flag & VRF_MASK), COND_GT, skip_bb);
  set_curbb(nextbb);
  new_ir_tjmp(val, table, range);
}

static void gen_switch_cond_recur(Stmt *swtch, VReg *vreg, Stmt **cases, int len) {
  if (len <= 2) {
    for (int i = 0; i < len; ++i) {
      BB *nextbb = new_bb();
      Stmt *c = cases[i];
      VReg *num = new_const_vreg(c->case_.value->fixnum, vreg->vsize, vreg->flag & VRF_MASK);
      new_ir_cjmp(vreg, num, COND_EQ, c->case_.bb);
      set_curbb(nextbb);
    }
    Stmt *def = swtch->switch_.default_;
    new_ir_jmp(def != NULL ? def->case_.bb : swtch->switch_.break_bb);
  } else {
    Stmt *min = cases[0];
    Stmt *max = cases[len - 1];
    Fixnum range = max->case_.value->fixnum - min->case_.value->fixnum + 1;
    if (range >= 4 && len > (range >> 1)) {
      gen_switch_cond_table_jump(swtch, vreg, cases, len);
      return;
    }

    BB *bbne = new_bb();
    int m = len >> 1;
    Stmt *c = cases[m];
    VReg *num = new_const_vreg(c->case_.value->fixnum, vreg->vsize, vreg->flag & VRF_MASK);
    new_ir_cjmp(vreg, num, COND_EQ, c->case_.bb);
    set_curbb(bbne);

    BB *bblt = new_bb();
    BB *bbgt = new_bb();
    new_ir_cjmp(vreg, num, COND_GT, bbgt);
    set_curbb(bblt);
    gen_switch_cond_recur(swtch, vreg, cases, m);
    set_curbb(bbgt);
    gen_switch_cond_recur(swtch, vreg, cases + (m + 1), len - (m + 1));
  }
}

static void gen_switch_cond(Stmt *stmt) {
  Expr *value = stmt->switch_.value;
  VReg *vreg = gen_expr(value);

  Vector *cases = stmt->switch_.cases;
  int len = cases->len;

  if (vreg->flag & VRF_CONST) {
    Fixnum value = vreg->fixnum;
    Stmt *target = stmt->switch_.default_;
    for (int i = 0; i < len; ++i) {
      Stmt *c = cases->data[i];
      if (c->case_.value != NULL && c->case_.value->fixnum == value) {
        target = c;
        break;
      }
    }

    BB *nextbb = new_bb();
    new_ir_jmp(target != NULL ? target->case_.bb : stmt->switch_.break_bb);
    set_curbb(nextbb);
  } else {
    if (len > 0) {
      // Sort cases in increasing order.
      qsort(cases->data, len, sizeof(void*), compare_cases);

      if (stmt->switch_.default_ != NULL)
        --len;  // Ignore default.
      gen_switch_cond_recur(stmt, vreg, (Stmt**)cases->data, len);
    } else {
      Stmt *def = stmt->switch_.default_;
      new_ir_jmp(def != NULL ? def->case_.bb : stmt->switch_.break_bb);
    }
  }
  set_curbb(new_bb());
}

static void gen_switch(Stmt *stmt) {
  BB *save_break;
  BB *break_bb = stmt->switch_.break_bb = push_break_bb(&save_break);

  Vector *cases = stmt->switch_.cases;
  for (int i = 0, len = cases->len; i < len; ++i) {
    BB *bb = new_bb();
    Stmt *c = cases->data[i];
    c->case_.bb = bb;
  }

  gen_switch_cond(stmt);

  // No bb setting.

  gen_stmt(stmt->switch_.body);

  set_curbb(break_bb);

  pop_break_bb(save_break);
}

static inline void gen_case(Stmt *stmt) {
  set_curbb(stmt->case_.bb);
  gen_stmt(stmt->case_.stmt);
}

static void gen_while(Stmt *stmt) {
  // cond_at_top (default, or builtin-expect=true)
  // cond:
  //   if (!<cond>) goto next
  // loop:
  //   <body>
  //   goto cond
  // next:

  // !cond_at_top (builtin-expect=false)
  //   goto cond
  // loop:
  //   <body>
  // cond:
  //   if (<cond>) goto loop
  // next:

  BB *save_break, *save_cont;
  BB *cond_bb = push_continue_bb(&save_cont);
  BB *next_bb = push_break_bb(&save_break);
  BB *loop_bb = new_bb();

  Expr *cond = stmt->while_.cond;
  bool cond_at_top = true;
  if (cond->kind == EX_EXPECT) {
    Expr *value = cond->bop.lhs;
    Expr *expect = cond->bop.rhs;
    assert(expect->kind == EX_FIXNUM);
    if (expect->fixnum == 0) {
      cond_at_top = false;
    }
    cond = value;
  }

  if (cond_at_top) {
    set_curbb(cond_bb);
    gen_cond_jmp(cond, loop_bb, next_bb);
    set_curbb(loop_bb);
  } else {
    new_ir_jmp(cond_bb);
    set_curbb(loop_bb);
  }

  gen_stmt(stmt->while_.body);

  if (cond_at_top) {
    new_ir_jmp(cond_bb);
  } else {
    set_curbb(cond_bb);
    gen_cond_jmp(cond, loop_bb, next_bb);
  }

  set_curbb(next_bb);
  pop_continue_bb(save_cont);
  pop_break_bb(save_break);
}

static void gen_do_while(Stmt *stmt) {
  // cond_at_top (default, or builtin-expect=true)
  //   goto loop
  // cond:
  //   if (!<cond>) goto next
  // loop:
  //   <body>
  //   goto cond
  // next:

  // !cond_at_top (builtin-expect=false)
  // loop:
  //   <body>
  // cond:
  //   if (<cond>) goto loop
  // next:

  BB *save_break, *save_cont;
  BB *cond_bb = push_continue_bb(&save_cont);
  BB *next_bb = push_break_bb(&save_break);
  BB *loop_bb = new_bb();

  Expr *cond = stmt->while_.cond;
  bool cond_at_top = !is_const_falsy(cond);
  if (cond_at_top && cond->kind == EX_EXPECT) {
    Expr *value = cond->bop.lhs;
    Expr *expect = cond->bop.rhs;
    assert(expect->kind == EX_FIXNUM);
    if (expect->fixnum == 0) {
      cond_at_top = false;
    }
    cond = value;
  }

  if (cond_at_top) {
    new_ir_jmp(loop_bb);
    set_curbb(cond_bb);
    gen_cond_jmp(cond, loop_bb, next_bb);
  }

  set_curbb(loop_bb);
  gen_stmt(stmt->while_.body);

  if (cond_at_top) {
    new_ir_jmp(cond_bb);
  } else {
    set_curbb(cond_bb);
    gen_cond_jmp(cond, loop_bb, next_bb);
  }

  set_curbb(next_bb);
  pop_continue_bb(save_cont);
  pop_break_bb(save_break);
}

static void gen_for(Stmt *stmt) {
  // cond_at_top (default, or builtin-expect=true)
  //    <pre>
  //  cond:
  //    if (!<cond>) goto next
  //  loop:
  //    <body>
  //  continu:
  //    <post>
  //    jmp cond
  //  next:

  // !cond_at_top (builtin-expect=false)
  //    <pre>
  //    goto cond
  //  loop:
  //    <body>
  //  continu:
  //    <post>
  //  cond:
  //    if (<cond>) goto loop
  //  next:

  BB *save_break, *save_cont;
  BB *continue_bb = push_continue_bb(&save_cont);
  BB *next_bb = push_break_bb(&save_break);

  BB *loop_bb = new_bb();
  BB *cond_bb = new_bb();

  if (stmt->for_.pre != NULL)
    gen_expr_stmt(stmt->for_.pre);

  Expr *cond = stmt->for_.cond;
  bool cond_at_top = true;
  if (cond != NULL && cond->kind == EX_EXPECT) {
    Expr *value = cond->bop.lhs;
    Expr *expect = cond->bop.rhs;
    assert(expect->kind == EX_FIXNUM);
    if (expect->fixnum == 0) {
      cond_at_top = false;
    }
    cond = value;
  }

  if (cond_at_top) {
    set_curbb(cond_bb);
    if (cond != NULL)
      gen_cond_jmp(cond, loop_bb, next_bb);
    set_curbb(loop_bb);
  } else {
    new_ir_jmp(cond_bb);
    set_curbb(loop_bb);
  }

  gen_stmt(stmt->for_.body);

  set_curbb(continue_bb);
  if (stmt->for_.post != NULL)
    gen_expr_stmt(stmt->for_.post);

  if (cond_at_top) {
    new_ir_jmp(cond_bb);
  } else {
    set_curbb(cond_bb);
    if (cond != NULL)
      gen_cond_jmp(cond, loop_bb, next_bb);
    else
      new_ir_jmp(loop_bb);
  }

  set_curbb(next_bb);
  pop_continue_bb(save_cont);
  pop_break_bb(save_break);
}

static void gen_break(void) {
  assert(s_break_bb != NULL);
  BB *bb = new_bb();
  new_ir_jmp(s_break_bb);
  set_curbb(bb);
}

static void gen_continue(void) {
  assert(s_continue_bb != NULL);
  BB *bb = new_bb();
  new_ir_jmp(s_continue_bb);
  set_curbb(bb);
}

static inline void gen_goto(Stmt *stmt) {
  assert(curfunc->label_table != NULL);
  GotoLabel *goto_label = table_get(curfunc->label_table, stmt->goto_.label->ident);
  assert(goto_label != NULL);
  new_ir_jmp(goto_label->label_stmt->label.bb);
  set_curbb(new_bb());
}

static inline void gen_label(Stmt *stmt) {
  if (stmt->label.bb != NULL)  // This case happens when the label is not used.
    set_curbb(stmt->label.bb);
  gen_stmt(stmt->label.stmt);
}

void gen_clear_local_var(const VarInfo *varinfo) {
  if (is_prim_type(varinfo->type))
    return;

  VReg *vreg = new_ir_bofs(varinfo->local.frameinfo)->dst;
  gen_clear(varinfo->type, vreg);
}

static void gen_vardecl(VarDecl *decl) {
  assert(decl->init_stmt != NULL);
  VarInfo *varinfo = decl->varinfo;
  assert(varinfo != NULL);
  gen_clear_local_var(varinfo);
  gen_stmt(decl->init_stmt);
}

void gen_stmt(Stmt *stmt) {
  if (stmt == NULL)
    return;

  switch (stmt->kind) {
  case ST_EMPTY: break;
  case ST_EXPR:  gen_expr_stmt(stmt->expr); break;
  case ST_RETURN:  gen_return(stmt); break;
  case ST_BLOCK:  gen_block(stmt); break;
  case ST_IF:  gen_if(stmt); break;
  case ST_SWITCH:  gen_switch(stmt); break;
  case ST_CASE: gen_case(stmt); break;
  case ST_WHILE:  gen_while(stmt); break;
  case ST_DO_WHILE:  gen_do_while(stmt); break;
  case ST_FOR:  gen_for(stmt); break;
  case ST_BREAK:  gen_break(); break;
  case ST_CONTINUE:  gen_continue(); break;
  case ST_GOTO:  gen_goto(stmt); break;
  case ST_LABEL:  gen_label(stmt); break;
  case ST_VARDECL:  gen_vardecl(stmt->vardecl); break;
  case ST_ASM:  gen_asm(stmt); break;
  }
}

////////////////////////////////////////////////

void prepare_register_allocation(Function *func) {
  FuncBackend *fnbe = func->extra;
  bool require_stack_frame = func->type->func.vaargs || fnbe->stack_work_size_vreg != NULL;

  for (int i = 0; i < func->scopes->len; ++i) {
    Scope *scope = (Scope*)func->scopes->data[i];
    for (int j = 0; j < scope->vars->len; ++j) {
      VarInfo *varinfo = scope->vars->data[j];
      if (!is_local_storage(varinfo))
        continue;
      VReg *vreg = varinfo->local.vreg;
      if (vreg == NULL) {
        assert(!is_prim_type(varinfo->type));
        // Whether it is a parameter or local variable defined in a function,
        // it is needed to access relative to base pointer.
        require_stack_frame = true;
        continue;
      }

#if STRUCT_ARG_AS_POINTER
      assert(is_prim_type(varinfo->type) ||
             (varinfo->type->kind == TY_STRUCT && varinfo->storage & VS_PARAM));
#else
      assert(is_prim_type(varinfo->type));
#endif
      if (vreg->flag & (VRF_FORCEMEMORY | VRF_STACK_PARAM)) {
        spill_vreg(vreg);
        require_stack_frame = true;
      }
    }
  }

  if (require_stack_frame)
    fnbe->ra->flag |= RAF_STACK_FRAME;
}

void map_virtual_to_physical_registers(RegAlloc *ra) {
  for (int i = 0, vreg_count = ra->vregs->len; i < vreg_count; ++i) {
    VReg *vreg = ra->vregs->data[i];
    if (vreg == NULL)
      continue;
    assert(!(vreg->flag & VRF_CONST) && vreg->virt >= 0);
    vreg->phys = ra->intervals[vreg->virt].phys;
  }
}

// Detect living registers for each instruction.
void detect_living_registers(RegAlloc *ra, BBContainer *bbcon) {
  int maxbit = ra->settings->regset[GPREG].phys_max + ra->settings->regset[FPREG].phys_max;
  unsigned long living_pregs = 0;
  assert((int)sizeof(living_pregs) * CHAR_BIT >= maxbit);
  LiveInterval **livings = ALLOCA(sizeof(*livings) * maxbit);
  for (int i = 0; i < maxbit; ++i)
    livings[i] = NULL;

#define VREGFOR(li, ra)  ((VReg*)ra->vregs->data[li->virt])
#define BITNO(li, ra)    (li->phys + (VREGFOR(li, ra)->flag & VRF_FLONUM ? floreg_offset : 0))
  const int floreg_offset = ra->settings->regset[GPREG].phys_max;
  // Activate function parameters a priori.
  for (int i = 0; i < ra->vregs->len; ++i) {
    LiveInterval *li = ra->sorted_intervals[i];
    assert(li != NULL);
    if (li->start >= 0)
      break;
    if (li->state != LI_NORMAL || VREGFOR(li, ra) == NULL)
      continue;
    int bitno = BITNO(li, ra);
    living_pregs |= 1UL << bitno;
    livings[bitno] = li;
  }

  int nip = 0, head = 0;
  for (int i = 0; i < bbcon->len; ++i) {
    BB *bb = bbcon->data[i];
    for (int j = 0; j < bb->irs->len; ++j, ++nip) {
      // Eliminate deactivated registers.
      for (int k = 0; k < maxbit; ++k) {
        LiveInterval *li = livings[k];
        if (li != NULL && nip == li->end) {
          assert(BITNO(li, ra) == k);
          living_pregs &= ~(1UL << k);
          livings[k] = NULL;
        }
      }

      // Store living vregs to IR_CALL.
      IR *ir = bb->irs->data[j];
      if (ir->kind == IR_CALL) {
        ir->call->living_pregs = living_pregs;
      }

      // Add activated registers.
      for (; head < ra->vregs->len; ++head) {
        LiveInterval *li = ra->sorted_intervals[head];
        if (li->start > nip)
          break;
        if (li->state != LI_NORMAL)
          continue;
        if (nip == li->start) {
          assert(VREGFOR(li, ra) != NULL);
          int bitno = BITNO(li, ra);
          living_pregs |= 1UL << bitno;
          livings[bitno] = li;
        }
      }
    }
  }
#undef BITNO
#undef VREGFOR
}

static size_t alloc_params_onto_stack_frame(Function *func, bool *prequire_stack_frame) {
  FuncBackend *fnbe = func->extra;
  assert(fnbe->frame_size == 0);
  size_t frame_size = 0;
  int param_offset = calculate_func_param_bottom(func);
  fnbe->vaarg_frame_info.offset = param_offset;

  if (func->type->func.vaargs) {
#if VAARG_FP_AS_GP
    // Register parameters are put below stack frame, so not added to frame_size.
#else
    int total = kArchSetting.max_reg_args[GPREG] + kArchSetting.max_reg_args[FPREG];
    frame_size = total * TARGET_POINTER_SIZE;
#endif
  }

  bool require_stack_frame = false;

#if EXTRA_RETURN_STRUCT_REGISTER
  const int arg_start = 0;
#else
  const Type *rettype = func->type->func.ret;
  const int arg_start = rettype->kind == TY_STRUCT && !is_small_struct(rettype) ? 1 : 0;
#endif
  int reg_index[2] = {arg_start, 0};  // [0]=gp-reg, [1]=fp-reg

  for (int i = 0; i < func->params->len; ++i) {
    VarInfo *varinfo = func->params->data[i];
    assert(is_local_storage(varinfo));
    const Type *type = varinfo->type;
    size_t align = align_size(type);
    bool is_flo = is_flonum(type);
    FrameInfo *fi = varinfo->local.frameinfo;
    size_t size = fi->size;  // type_size(type);
    if (is_small_struct(type)) {
      size_t n = (size + (TARGET_POINTER_SIZE - 1)) / TARGET_POINTER_SIZE;
      if (reg_index[is_flo] + (int)n <= kArchSetting.max_reg_args[is_flo]) {
        // Small struct, passed by register.
        reg_index[GPREG] += n;

        // Allocate stack frame.
        frame_size = ALIGN(frame_size + MAX(size, 1), align);
        fi->offset = -(int)frame_size;
        continue;
      }
    } else if (!is_stack_param(type)
#if STRUCT_ARG_AS_POINTER
               || (varinfo->storage & VS_PARAM)
#endif
    ) {
      assert(varinfo->local.vreg != NULL);
      if (!(varinfo->local.vreg->flag & VRF_STACK_PARAM)) {
        reg_index[is_flo] += 1;
        continue;  // Passed by register.
      }
      size = align = TARGET_POINTER_SIZE;
    }

    fi->offset = param_offset = ALIGN(param_offset, align);
    param_offset += ALIGN(size, TARGET_POINTER_SIZE);
    require_stack_frame = true;
  }

  *prequire_stack_frame = require_stack_frame;
  return frame_size;
}

static size_t alloc_locals_onto_stack_frame(Function *func, size_t frame_size) {
  for (int i = 0; i < func->scopes->len; ++i) {
    Scope *scope = func->scopes->data[i];
    for (int j = 0; j < scope->vars->len; ++j) {
      VarInfo *varinfo = scope->vars->data[j];
      if (!is_local_storage(varinfo) || (varinfo->storage & VS_PARAM))
        continue;

      if (is_prim_type(varinfo->type)) {
        // Primitive type variables are handled according to RegAlloc results in below.
        continue;
      }

      assert(varinfo->local.vreg == NULL);

      Type *type = varinfo->type;
      size_t size = type_size(type);
      if (type->kind == TY_STRUCT && type->struct_.info->flag & SIF_FLEXIBLE) {
        Initializer *init = varinfo->local.init;
        if (init != NULL) {
          int m = type->struct_.info->member_count;
          assert(init->kind == IK_MULTI);
          assert(init->multi->len == m);
          Initializer *e = init->multi->data[m - 1];
          if (e != NULL) {
            assert(e->kind == IK_MULTI);
            MemberInfo *member = &type->struct_.info->members[m - 1];
            assert(member->type->kind == TY_ARRAY);
            size += type_size(member->type->pa.ptrof) * e->multi->len;
          }
        }
      }
      if (size < 1)
        size = 1;
      size_t align = align_size(type);

      frame_size = ALIGN(frame_size + size, align);
      FrameInfo *fi = varinfo->local.frameinfo;
      assert(fi != NULL);
      fi->offset = -(int)frame_size;
    }
  }
  return frame_size;
}

static size_t alloc_spilled_vregs_onto_stack_frame(RegAlloc *ra, size_t frame_size) {
  for (int i = 0; i < ra->vregs->len; ++i) {
    LiveInterval *li = ra->sorted_intervals[i];
    if (li->state != LI_SPILL)
      continue;
    VReg *vreg = ra->vregs->data[li->virt];
    assert(vreg->flag & VRF_SPILLED);
    if (vreg->flag & VRF_STACK_PARAM)
      continue;  // Handled in above, so skip here.

    int size, align;
    size = align = 1 << vreg->vsize;

    frame_size = ALIGN(frame_size + size, align);
    vreg->frame.offset = -(int)frame_size;
  }
  return frame_size;
}

void alloc_stack_variables_onto_stack_frame(Function *func) {
  bool require_stack_frame;
  size_t frame_size = alloc_params_onto_stack_frame(func, &require_stack_frame);
  frame_size = alloc_locals_onto_stack_frame(func, frame_size);

  FuncBackend *fnbe = func->extra;
  frame_size = alloc_spilled_vregs_onto_stack_frame(fnbe->ra, frame_size);

  fnbe->frame_size = frame_size;

  assert(!(require_stack_frame || frame_size > 0) || (fnbe->ra->flag & RAF_STACK_FRAME));
}

bool gen_defun(Function *func) {
  VarInfo *funcvi = scope_find(global_scope, func->ident->ident, NULL);
  if (is_function_omitted(funcvi, func->attributes)) {
    // Omit function: func->extra preserves the value (NULL).
    return false;
  }

  curfunc = func;
  static_vars = func->static_vars;
  FuncBackend *fnbe = func->extra = calloc_or_die(sizeof(FuncBackend));
  fnbe->ra = NULL;
  fnbe->bbcon = NULL;
  fnbe->ret_bb = NULL;
  fnbe->struct_retvar = NULL;
  fnbe->inline_result_dst = NULL;
  fnbe->funcalls = NULL;
  fnbe->frame_size = 0;
  fnbe->vaarg_frame_info.size = -1;  // Dummy.
  fnbe->vaarg_frame_info.offset = 0;  // Calculated in later.
  fnbe->stack_work_size = 0;
  fnbe->stack_work_size_vreg = NULL;

  fnbe->bbcon = new_func_blocks();
  set_curbb(new_bb());
  fnbe->ra = curra = new_reg_alloc(&kArchRegAllocSettings);

  // Allocate BBs for goto labels.
  if (func->label_table != NULL) {
    Table *label_table = func->label_table;
    const Name *name;
    GotoLabel *goto_label;
    for (int it = 0; (it = table_iterate(label_table, it, &name, (void**)&goto_label)) != -1; ) {
      goto_label->label_stmt->label.bb = new_bb();
    }
  }

  alloc_variable_registers(func);

  fnbe->ret_bb = new_bb();

  // Statements
  gen_stmt(func->body_block);

  set_curbb(fnbe->ret_bb);
  curbb = NULL;
  detect_from_bbs(fnbe->bbcon);

  curfunc = NULL;
  static_vars = NULL;
  curra = NULL;
  return true;
}

static inline void gen_defun_after(Function *func) {
  FuncBackend *fnbe = func->extra;
  curfunc = func;
  curra = fnbe->ra;

  optimize(fnbe->ra, fnbe->bbcon);

  prepare_register_allocation(func);
  tweak_irs(fnbe);
  analyze_reg_flow(fnbe->bbcon);

  alloc_physical_registers(fnbe->ra, fnbe->bbcon);
  map_virtual_to_physical_registers(fnbe->ra);
  detect_living_registers(fnbe->ra, fnbe->bbcon);

  alloc_stack_variables_onto_stack_frame(func);

  curfunc = NULL;
  curra = NULL;
}

static void gen_decl(Declaration *decl) {
  if (decl == NULL)
    return;

  switch (decl->kind) {
  case DCL_DEFUN:
    {
      Function *func = decl->defun.func;
      if (gen_defun(func))
        gen_defun_after(func);
    }
    break;
  case DCL_ASM:
    break;
  }
}

void gen(Vector *decls) {
  if (decls == NULL)
    return;

  for (int i = 0, len = decls->len; i < len; ++i) {
    Declaration *decl = decls->data[i];
    if (decl == NULL)
      continue;
    gen_decl(decl);
  }
}
