#pragma once

#include "ast.h"

Expr *string_expr(const Token *token, char *str, ssize_t len, enum StrKind kind);
Expr *calc_type_size(const Type *type);
#ifndef __NO_VLA
Expr *reserve_vla_type_size(Type *type);
Expr *calc_vla_size(Type *type);
#endif
Expr *make_cast(Type *type, const Token *token, Expr *sub, bool is_explicit);
Expr *reduce_refer(Expr *expr);
Expr *make_refer(const Token *tok, Expr *expr);
Expr *promote_to_int(Expr *expr);
Expr *make_expr_num_bop(enum ExprKind kind, const Token *tok, Expr *lhs, Expr *rhs);
#ifndef __NO_BITFIELD
Expr *extract_bitfield_value(Expr *src, const MemberInfo *member);
Expr *assign_to_bitfield(const Token *tok, Expr *lhs, Expr *rhs, const MemberInfo *member);
#endif
Expr *incdec_of(enum ExprKind kind, Expr *target, const Token *tok);
Expr *make_expr_cmp(enum ExprKind kind, const Token *tok, Expr *lhs, Expr *rhs);
Expr *make_cond(Expr *expr);
Expr *make_not_expr(const Token *tok, Expr *expr);
Expr *transform_assign_with(const Token *tok, Expr *lhs, Expr *rhs);
Expr *simplify_funcall(Expr *funcall);
