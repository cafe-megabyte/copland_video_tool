declare module '*.c'
